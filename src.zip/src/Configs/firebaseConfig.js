
import firebase from 'firebase/compat/app';
// import {GoogleAuthProvider} from 'firebase/auth'

import 'firebase/compat/auth'
import 'firebase/compat/firestore'
import 'firebase/compat/storage'

const firebaseConfig = {
  apiKey: "AIzaSyAG28Z6CPPM2OirjEEzUJUhTvXdB-YXhmg",
  authDomain: "ecommerce-website-6fd7e.firebaseapp.com",
  projectId: "ecommerce-website-6fd7e",
  storageBucket: "ecommerce-website-6fd7e.appspot.com",
  messagingSenderId: "502310810638",
  appId: "1:502310810638:web:43a0b6c9a1750a2fad785f"
};
firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const fs = firebase.firestore();
const storage = firebase.storage();
// const Googleprovider = new GoogleAuthProvider();

export {auth,fs,storage  }