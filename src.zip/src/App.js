
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Components/Home';
import Login from './Components/Login';
import Signup from './Components/Signup';
import Cart from './Components/Cart'; 
import Addproduct from './Components/Addproduct';
import {pgFoF} from './Components/pgFoF';
import Payment from './Components/Payment';
import OnPay from './Components/OnPay';
import CashPay  from './Components/CashPay';
import Profile from './Components/Profile';
import Header from './Components/Header';


function App() {
  return (
    
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Home />} />
        <Route exact path='/home' element={<Home />} />
        <Route exact path='/login' element={<Login />} />
        <Route exact path='/signup' element={<Signup />} />
        <Route exact path='/profile' element={<Profile />} />
        <Route exact path='/cart' element={<Cart />} />
        <Route path='/payment' element={<Payment />} />
        <Route path='/onpay' element={<OnPay />} />
        <Route path='/cashpay' element={<CashPay />} />
        <Route exact path='/addproduct' element={<Addproduct />} />
        
       
          <Route element={pgFoF} />
        
     </Routes>
    </BrowserRouter>
  );
}

export default App;
