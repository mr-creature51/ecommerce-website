import React from 'react'
import { fs, auth } from '../Configs/firebaseConfig'
// import { Link } from 'react-router-dom'



const IndividualCartProduct = ({ cartProduct, IncreaseCartProduct, DecreaseCartProduct }) => {

    const IncreaseProduct = () => {
        IncreaseCartProduct(cartProduct);
    }

    const DecreaseProduct = () => {
        DecreaseCartProduct(cartProduct);

    }

    const DeleteProduct = () => {
        auth.onAuthStateChanged(user => {
            if (user) {
                fs.collection('Cart ' + user.uid).doc(cartProduct.ID).delete().then(() => {
                    console.log('successfully deleted');
                })
            }
        })
    }

    return (

        <>
            

            <section class="text-gray-600 body-font overflow-hidden">
                <div class=" container px-5 py-2 mx-auto">
                    <div class=" border border-[#e4e4e4]  lg:w-4/5 mx-auto flex flex-wrap">
                        <img alt="ecommerce" class=" lg:w-1/6 w-full lg:h-1/2  object-cover object-center rounded" src={cartProduct.url} />
                        <div class="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">

                            <h1 class="text-gray-900 text-2xl title-font font-medium mb-1">{cartProduct.title}</h1>


                            <p class="leading-relaxed">{cartProduct.description}</p>
                            <div class="flex mt-2 items-center pb- border-b-2 border-gray-100 mb-5">
                                <div className='title-font font-medium text-1xl text-gray-900'>$ {cartProduct.price}</div>

                            </div>
                            <div class="flex">
                                <span class="title-font font-medium text-2xl text-gray-900">${cartProduct.TotalProductPrice}</span>
                                <button  onClick={IncreaseProduct} class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                                    </svg>
                                </button>

                                <div class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">{cartProduct.qty}</div>

                                <button  onClick={DecreaseProduct}  class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash-circle-fill" viewBox="0 0 16 16">
                                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z" />
                                    </svg>
                                </button>



                                <button  onClick={DeleteProduct} class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">
                                   DELETE
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>




        </>
    )
}

export default IndividualCartProduct
