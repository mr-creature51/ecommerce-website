import React from 'react'
import  IndividualCartProduct  from './IndividualCartProduct'

const CartProducts = ({cartProducts , IncreaseCartProduct , DecreaseCartProduct}) => {
    return cartProducts.map((cartProduct)=>(
        <IndividualCartProduct key={cartProduct.ID} cartProduct={cartProduct}
            IncreaseCartProduct={IncreaseCartProduct}
            DecreaseCartProduct={DecreaseCartProduct}
        />
    ))
}

export default CartProducts;