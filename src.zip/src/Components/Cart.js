import React, { createContext, useEffect, useState } from 'react'
import Navbar from './Navbar';
import { fs, auth } from '../Configs/firebaseConfig'
import CartProducts from './CartProducts';
import Payment from './Payment';


const d1 = createContext();
const d2 = createContext();


const Cart = () => {
  
  function GetCurrentUser(){
    const [user, setUser]=useState(null);
    useEffect(()=>{
        auth.onAuthStateChanged(user=>{
            if(user){
                fs.collection('users').doc(user.uid).get().then(snapshot=>{
                    setUser(snapshot.data().FullName);
                })
            }
            else{
                setUser(null);
            }
        })
    },[])
    return user;
}

const user = GetCurrentUser();
  console.log(user);
  

  const [cartProducts, setCartProducts]=useState([]);

    // getting cart products from firestore collection and updating the state
    useEffect(()=>{
        auth.onAuthStateChanged(user=>{
            if(user){
                fs.collection('Cart ' + user.uid).onSnapshot(snapshot=>{
                    const newCartProduct = snapshot.docs.map((doc)=>({
                        ID: doc.id,
                        ...doc.data(),
                    }));
                    setCartProducts(newCartProduct);                    
                })
            }
            else{
                console.log('user is not signed in to retrieve cart');
            }
        })
    },[])

    // console.log(cartProducts);
//  ------------------------------------------------set paymet qty and total price----------------------------------------------------------------  
    const q = cartProducts.map(cart => {
        return (cart.qty)
        
    })
   let TotalPrice= 0;
    q.forEach(n => TotalPrice += n)
    // console.log(s);


    const z = cartProducts.map(cart => {
        return (cart.TotalProductPrice)
        
    })
   let quanty = 0;
    z.forEach(n => quanty += n)
    // console.log(quanty);


// ------------------------------------------------------=---------------------------------------
  let Product

  const IncreaseCartProduct = (cartProducts) => { 
    console.log(cartProducts);
    Product=cartProducts;
    Product.qty=Product.qty+1;
    Product.TotalProductPrice=Product.qty*Product.price;
    // updating in database
    auth.onAuthStateChanged(user=>{
        if(user){
            fs.collection('Cart ' + user.uid).doc(cartProducts.ID).update(Product).then(()=>{
                console.log('increment added');
            })
        }
        else{
            console.log('user is not logged in to increment');
        }
    })
  }

  const DecreaseCartProduct = (cartProducts) => { 
    console.log(cartProducts);
    Product=cartProducts;
    Product.qty=Product.qty-1;
    Product.TotalProductPrice=Product.qty*Product.price;
    // updating in database
    auth.onAuthStateChanged(user=>{
        if(user){
            fs.collection('Cart ' + user.uid).doc(cartProducts.ID).update(Product).then(()=>{
                console.log('decrement added');
            })
        }
        else{
            console.log('user is not logged in to decrement');
        }
    })
  }
  
  return (
    <>
      <Navbar user={user} />
      <br></br>

      {cartProducts.length > 0 && (
                <div className='container-fluid'>
                  <h1 className='text-center'>Cart</h1>
                  <CartProducts cartProducts={cartProducts} IncreaseCartProduct={IncreaseCartProduct} DecreaseCartProduct={DecreaseCartProduct} />  
                
                  <d1.Provider value={TotalPrice }>
                      <d2.Provider value={quanty }>
                      <Payment />
                      </d2.Provider>
                  </d1.Provider>
                  
                  
                </div>
            )}
            {cartProducts.length < 1 && (
                <div className='container-fluid'>No products to show</div>
            ) }
    </>
  )
}

export default Cart
export { d1,d2 }
