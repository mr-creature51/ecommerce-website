import React from 'react'

export const pgFoF = () => {
  return (
    <div>
       404
    </div>
  )
}


