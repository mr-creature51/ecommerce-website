import React, { useContext } from 'react'
import { Link } from 'react-router-dom'
import Foot from './Foot'
import { d1, d2 } from './Cart'
const Payment = () => {
  const totalprice = useContext(d1);
  const quenty = useContext(d2);
  return (


    <div>


      <section class="text-gray-600 body-font overflow-hidden">
        <div class="container px-5 py-24 mx-auto">
          <div class=" border border-[#e4e4e4] lg:w-4/5 mx-auto flex flex-wrap">

            <div class="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">

              <h1 class="text-gray-900 text-3xl title-font font-medium mb-1">Cart Summary</h1>

              <p class="leading-relaxed">Total no. of Products -   {totalprice}    </p>
              <p class="leading-relaxed">Total Price To Pay -  ${quenty}     </p>
              <div class="flex mt-6 items-center pb-5 border-b-2 border-gray-100 mb-5">


              </div>
              <div class="flex">
                <Link to='/onpay'><button class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">Pay With Card</button></Link>
                <Link to='/cashpay'><button><button class="flex ml-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">Cash on Delivery</button></button></Link>

              </div>
            </div>
          </div>
        </div>
      </section>

    <Foot/>


    </div>
  )
}

export default Payment
