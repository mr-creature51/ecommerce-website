import React from 'react'


export const IndividualProduct = ({individualProduct, addToCart}) => {
    console.log(individualProduct);
    const handleAddToCart=()=>{
        addToCart(individualProduct);
    }   
    return (
         <div className='product'>
        
             <section className="text-gray-600 body-font">
                <div className="container px-5 py-24 mx-auto">
                    <div className="flex flex-wrap -m-4">
                        <div className="border border-[#e4e4e4]  lg:w-1/4 md:w-1/2 p-4 w-full">
                            <a className="block relative h-48 rounded overflow-hidden">
                                <img alt="ecommerce" className="object-cover object-center w-full h-full block" src={individualProduct.url} />
                            </a>
                            <div className="mt-4">
                                <h3 className="text-gray-500 text-xs tracking-widest title-font mb-1">{individualProduct.title}</h3>
                                <h2 className="text-gray-900 title-font text-lg font-medium">{individualProduct.description}</h2>
                                <p className="mt-1">${individualProduct.price}</p>
                            </div>
                            <button class="inline-flex items-center bg-gray-100 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-10 md:mt-0"   onClick={handleAddToCart}  >Add to Cart</button>
                              
                            
                            
                        </div>

                    </div>
                </div>
            </section> 




        </div> 
    )
}
